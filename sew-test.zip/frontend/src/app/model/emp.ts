interface Employee {
  id: number,
  firstname: number,
  lastname: number
}
